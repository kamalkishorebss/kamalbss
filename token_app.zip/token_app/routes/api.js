var express = require('express');
var router = express.Router();
var multer = require('multer');
var mime = require('mime-types');
var favicon = require('serve-favicon');
var nodemailer = require('nodemailer');

//****************** controllers************************//
//var Usermodel = require('../model/signupmodel');
var userController = require('../controller/usercontroller');
//var usermodel = require('../model/contactmodel');
var usercontact = require('../controller/contactcontroller');
//var blogmodel = require('../model/addblogmodel');
var userblog = require('../controller/addblogcontroller');


//***************uploadsimage****************//
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+ mime.extension(file.mimetype));
    }
});
var upload = multer({ storage: storage });


//************************addedblog images******************************************//
var blogupload = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploadsblog/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+ mime.extension(file.mimetype));
    }
});
var uploadblog = multer({ storage: blogupload });


// routes 
router.post('/login',userController.login);


router.post('/signup', upload.single('file'), userController.signup);


router.post('/addblog', uploadblog.single('file'), userblog.addblog);


router.get('/home', userblog.home);


router.get('/listblog', userblog.listblog);
router.delete('/delete/:id', userblog.delete);
router.get('/blogview/:id', userblog.viewblog);


router.get('/profile', userController.profile);


router.post('/contact',usercontact.contact);








module.exports = router;