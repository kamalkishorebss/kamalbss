var express = require('express');
var router = express.Router();
var userController = require('../controller/usercontroller');
var contactController = require('../controller/contactcontroller');
var addblogController = require('../controller/addblogcontroller');
//var userContact = require('../controller/usercontroller');

/* GET home page. */
router.get('/',function(req,res,next){
	res.render('index',{title:'index'});
});








module.exports = router;
