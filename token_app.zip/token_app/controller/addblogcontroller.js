var Usermodel = require('../model/addblogmodel');

//****************************************addblogschema************************************//
module.exports.addblog =  function(req, res) 
{
    var user = new Usermodel();
    user.title = req.body.title;
    user.content = req.body.content;
	user.tags = req.body.tags;
	//console.log(user.content);
	user.file = req.file.filename;
    //console.log(req.body);
    user.save(function (err, data) {
					if (err) 
					{
						//console.log(err);
						res.send(err);
					}
					else
						{
						console.log(data);
						res.send(data);
					    }
			
		})
	};
	
	//***************************home function*****************************//
	module.exports.home = function(req,res)
	{
		Usermodel.find({},function(err,data)
		{
			if(err)
			{
				console.log(err);
			}
			else
			{
				//console.log(data);
				res.send(data);
			}
		});
	};
	
	
	
	
	//***************************added blog*****************************//
	module.exports.listblog=function(req, res)
	{
	
	 Usermodel.find({},function(err,data){
				if(err){
					console.log('err',err)
				}
				else
				{
					res.send(data);
					//console.log(data);
				}
								
			  
					
		});


	};
	
	
	
	
	//****************************deleteblog*****************************//
	module.exports.delete = function(req, res)
	{
		var uid = req.params.id;
		
	  Usermodel.findByIdAndRemove(uid, function(err, info) 
	  {
       if (err) {
				res.send(err);
           }
		   else{
			   res.send(info);
		   }
	  
     });
	};
	
	
	
	//***************************view blog*******************************//
	module.exports.viewblog = function(req, res)
	{
		var uid = req.params.id;
		
	  Usermodel.findById(uid, function(err, info) 
	  {
       if (err) {
				res.send(err);
           }
		   else{
			   res.send(info);
		   }
	  
     });
	};
	//******************************Editblog******************************//
	module.exports.editblog = function(req, res)
	{
		var uid = req.params.id;
		
	  Usermodel.findById(uid, function(err, info) 
	  {
       if (err) {
				res.send(err);
           }
		   else{
			   res.send(info);
		   }
	  
     });
	};
	//**********************************saveeditblog***************************//
	module.exports.saveEditblog = function(req, res)
	{
		var uid = req.params.id;
		
	  Usermodel.findById(uid, function(err, saveBlog) 
	  {
		saveBlog.title = req.body.title;
        saveBlog.content = req.body.content;
        saveBlog.tags = req.body.tags; 
 		saveBlog.save(function(err,store)
		{
       if (err) {
				res.send(err);
           }
		   else{
			   res.send(store);
		   }
		
     });
	  });
	};