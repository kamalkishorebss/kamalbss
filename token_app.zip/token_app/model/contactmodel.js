var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var userSchema = new Schema({
 name: String,
 email: { type: String, required: true, unique: true },
 message: String
});



var User = mongoose.model('contact', userSchema);

module.exports = User;
