

//***************************homecontroller*****************************//
app.controller("homecontroller",function($scope,$http,$location){
	$http({
			method: 'GET',
			url: '/api/home'
		}).
		then(function successCallback(response) 
		{
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else
			{
				$scope.user = response.data; 
			}
		}, function errorCallback(response) 
		   {
			  console.log('error',response);
		   });
	
});
 


//*****************************logincontroller*************************//
 app.controller("Logincontroller",function($scope,$http,$location)
 {
	
	 $scope.signupPage= function()
	 {
		 $location.path('/signup');
	 }
	 
	$scope.loginpage = function(){
		
	 	$http({
		  method: 'POST',
		  url: '/api/login',
		  data: {email:$scope.email, password:$scope.password},
		}).then(function successCallback(response) {
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else if(response.data.status==true)
			{
				
				$location.path('/#');
	        }
			else 
			{
		    //$location.path('/login');
			console.log("invalid email/password");
			}
		}, function errorCallback(response) {
		    console.log('error',response);
		});
	 }
 });
 
 
 

//*****************************************signupcontroller*************************************//
app.controller("signupcontroller",function($scope ,$location, $http){
        
		$scope.signup = function(){
       var file = $scope.file;
      var uploadUrl = "api/signup";
        var fd = new FormData();
        fd.append('name',$scope.name);
        fd.append('email',$scope.email);
        fd.append('password',$scope.password);
        fd.append('file', $scope.file);
      
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
          console.log("success!!");
          $location.path("/login")
        })
        .error(function(){
          console.log("error!!");
        });
    };
	
});


//*******************************contactcontroller****************************// 
app.controller("contactcontroller",function($scope ,$location, $http){
        
		$scope.contact = function(){
		//console.log('$scope.name' ,$scope.name , '$scope.email' ,$scope.email);
		$http({
			method: 'POST',
			url: '/api/contact',
			data: {name:$scope.name, email:$scope.email,  message:$scope.message},
		}).
		then(function successCallback(response) 
		{
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else
			{
				if(response.data.status==true)
				//console.log(response);
				$location.path('/#');
			}
		}, function errorCallback(response) 
		   {
			  console.log('error',response);
		   });
	}

	
});


//*****************************************addblogcontroller*********************//
app.controller("addblogcontroller",function($scope,$http, $location){
	$scope.addblog = function(){
       var file = $scope.file;
	   console.log(file);
       var uploadUrl = "api/addblog";
        var fd = new FormData();
        fd.append('title',$scope.title);
		fd.append('content',$scope.content);
		fd.append('tags',$scope.tags);
        fd.append('file', file);
        
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
          //console.log("success!!");
          $location.path("/listblog")
        })
        .error(function(){
          console.log("error!!");
        });
    };

	
});


//****************************************listblog**************************************//
app.controller("listblogcontroller",function($scope, $http, $localStorage,$location){
	$scope.info1 = $localStorage.user;  
	 $scope.blog1 =  $localStorage.dd;
       $http({
			method: 'GET',
			url: '/api/listblog'
		}).
		then(function successCallback(response) 
		{
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else
			{
				$scope.user = response.data;
                $scope.currentPage = 1;
				$scope.totalItems = $scope.user.length;
				$scope.entryLimit = 9; 
				$scope.noOfpages = Math.ceil($scope.totalItems / $scope.entryLimit);				
			}
		}, function errorCallback(response) 
		   {
			  console.log('error',response);
		   });
		   
    //deletelist
	$scope.deletelist = function(id) {
			$http({
			method: 'DELETE',
			url: '/api/delete/' + id
		}).
		then(function successCallback(response) 
		{
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else
			{
				$scope.user.forEach(function(values,index)
				{
					if(values._id == id)
					{
						$scope.user.splice(index,1);
					}
				});
			}
		}), function errorCallback(response) 
		   {
			  console.log('error',response);
		   };
		};
//viewblog
$scope.view = function(id) {
	//alert("hi");
			$http({
			method: 'GET',
			url: '/api/blogview/' + id
		}).
		then(function successCallback(response) 
		{
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else
			{
				$scope.blog = response.data;
				$localStorage.user=$scope.blog;
				console.log($localStorage.user);
				$location.path('/blog1');
		    }
		
		}), function errorCallback(response) 
		   {
			  console.log('error',response);
		   };
		};
		
		//*****editBlog  		
	$scope.editBlog = function(id) 
	{
    $http({
    method:"GET",
    url:'/api/editblog/'+id,
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;

        $localStorage.dd=$scope.Blog;
        
        //console.log( $scope.updateValue)
        $location.path('/editblog');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


    }
	
	//save editblog in database
	$scope.saveEditBlog = function(id) 
	{
    $http({
    method:"POST",
    url:'api/editblog/'+id,
	data:{title:$scope.blog1.title,content:$scope.blog1.content,tags:$scope.blog1.tags}
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;

        $localStorage.dd=$scope.Blog;
        
        //console.log( $scope.updateValue)
        $location.path('/listblog');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


    }  
	   
});	



//***************************editblogcontroller*****************************// 
/*app.controller("editblogcontroller",function($scope,$http,$localStorage,$location)
{    $cope.updateblog =  $localStorage.dd;
	$scope.editBlog = function(id) 
	{
    $http({
    method:"GET",
    url:'api/editblog/'+id,
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;

        $localStorage.dd=$scope.Blog;
        
        //console.log( $scope.updateValue)
        $location.path('/editblog');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


    }
	
	//****save editblog in database
	$scope.saveEditBlog = function(id) 
	{
    $http({
    method:"POST",
    url:'api/editblog/'+id,
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;

        $localStorage.dd=$scope.Blog;
        
        //console.log( $scope.updateValue)
        $location.path('/listblog');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


    }
});*/

//******************************************profile************************************//
app.controller("profilecontroller",function($scope, $http){
           $http({
			   method: 'GET',
			   url: '/api/profile'
		   }).
            then(function successCallback(response)
			{
			if(response.data.error)
			    { 
		           $scope.error=response.data.error;
		        }
		    else
		        {
			       $scope.user = response.data;
				   //console.log($scope.user);
		        }
		    }, function errorCallback(response)
		            {
			         console.log('error',response);
		            }
            )		   
           	   
});



//**********************************viewblog****************************************//
