var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var userSchema = new Schema({
 title: String,
 content: String,
 file: String,
 tags: String
 });



var User = mongoose.model('addblog', userSchema);

module.exports = User;
