var express = require('express');
var router = express.Router();
var users = require('../model/usermodel');
var authn = require('./auth');
//console.log(users)
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/login',function(req, res, next){
res.render('login', {title: 'login'});	

});
router.get('/home',authn.auth,function(req,res,next){
	res.render('home',{user : req.session.email});
	
});


router.get('/logout',authn.auth,function(req,res,next){
	req.session.destroy(function(err)
	{
		if(err)
		{
			console.log('err',err);
		}
		else
		{
			res.redirect('login');
		}
	});
	
});

router.get('/signup',function(req, res, next){
res.render('signup', {title: 'signup'});	

});

router.get('/logout',function(req, res, next){
	

});

/*router.get('/login',function(req, res, next){
res.render('login', {title: 'login'});	

});
*/
/*router.post('/login',function(req, res, next){
console.log(req.param);
res.send(req.body);

});*/

//******************************************signup post********************************************//	
router.post('/signup',function(req, res){
	var user = new users();
	
	user.firstname=req.body.firstname;
    user.lastname=req.body.lastname;
    user.email=req.body.email;
	user.password=req.body.password;

	
	user.save(function (err, data) {
					if (err) {
						res.send(err);
					}else {
						res.send(data);
					}
				});
			/* users.findOne({email:req.body.email},function(err,person){
				if(err){
					console.log('err',err)
				}else{
					if(!person){
						user.save(function(err,data){
							if(err){
								console.log('err',err);
								}
								else{
								res.send(data);
									//res.redirect('/login');
								}
							});
						}else{
							res.send({error:"email not register"});
						}
					}
				}); */
});


//*****************************************************login post*******************************//	
router.post('/login',function(req, res){
var email=req.body.email;
var password=req.body.password;

	
	/*user.save(function (err, data) {
					if (err) {
						res.send(err);
					}else {
						res.send(data);
					}
				});*/
			 users.findOne({email:email},function(err,person){
				if(err){
					console.log('err',err)
				}else{
					if(person)
					{
					if(person.password == password)
					{
						req.session.email = person;
						res.redirect('home');
					//res.render('home',{user:person.email,title:"Home"});	
					}
              else{
				  res.send(err);
			  }					
					}
					else{
							res.send({error:"email/password not valid"});
						}
					}
				}); 
});	

//***************************************************view all user**************************************//
router.get('/viewAlluser',function(req, res){
	users.find({},function(err, users)
	{
		if(err) 
	       { 
             res.send(err); 
	        }
		else 
		   { 
	          res.render('view',{user : users}); 
	       }
	});
	
});
//*************************************************delete by id user*******************************//
router.get('/delete/:id', function(req, res){
	var uid = req.params.id;
users.findByIdAndRemove(uid, function(err) {
	
if (err) {
	console.log(err)
	}
else
{
  // we have deleted the user
  console.log('User deleted!');
res.redirect('/viewAlluser');
  }
  });
});

router.get('/edit/:id', function(req, res){
	var uid = req.params.id;
users.findById(uid, function(err, data) {
	if (err) {
	console.log(err)
	}
	else
	{
  // we have deleted the user
  console.log('User deleted!');
res.render('edit',{person:data});
  }
  });
});

router.post('/edit/:id', function(req, res)
{
	var uid = req.params.id;
	users.findById(uid, function(err,person)
	{
		person.firstname = req.body.firstname;
		person.lastname = req.body.lastname;
		
		person.save(function(err, data)
		{
			if(err)
			{
			res.send(err);
			}
			else{
				res.redirect('/viewAlluser');
				//res.send(data);
			}
		})
		
	});
});
module.exports = router;

