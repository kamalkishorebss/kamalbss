module.exports.index=function(req,res,next){
res.render('index',{abc:'hello'});
}
module.exports.hi=function(req,res,next){
res.json({title:'this is json file'});
}