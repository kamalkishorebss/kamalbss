var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var userSchema = new Schema({
  firstname: String,
  lastname:String,
  email: { type: String, required: true, unique: true },
  password: { type: Number, required: true}
});



var User = mongoose.model('user', userSchema);

module.exports = User;




/*var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var userSchema = new Schema({
  firstname: String,
  lastname:String,
  email: { type: String, required: true, unique: true },
  password: { type: Number, required: true}
});



var User = mongoose.model('user', userSchema);

module.exports = User;*/

