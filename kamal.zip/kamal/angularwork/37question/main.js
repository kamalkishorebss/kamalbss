
      var app = angular.module('countryApp', ['ngRoute']);

      app.config(function($routeProvider) {
        $routeProvider.
          when('/', {
            templateUrl: 'list1.html',
            controller: 'controller1'
          }).when('/page2', {
            templateUrl: 'list2.html',
            controller: 'controller2'
          }).otherwise({
            redirectTo: '/'
          });
      });

      app.controller('controller1', function ($scope, $http){
        $http.get('country.json').then(function(response) {
          $scope.countries = response.data.countries;
        });
      });

      app.controller('controller2', function ($scope,$http,$routeParams){
        $scope.name = $routeParams.$scope.countries;
      });
