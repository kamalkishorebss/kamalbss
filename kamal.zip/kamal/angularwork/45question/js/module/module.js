 var app = angular.module('myApp', ['ngRoute']);
      app.config(function($routeProvider) {
        $routeProvider.
          when('/view1', {
            templateUrl: 'js/view/view1.html',
            controller: 'controller1'
          }).
          when('/:countryId', {
            templateUrl: 'js/view/view2.html',
            controller: 'controller2'
          }).
          otherwise({
            redirectTo: '/view1'
          });
      });