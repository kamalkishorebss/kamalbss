 app.controller('controller1', function ($scope, countryService){
          countryService.list(function(data){
          $scope.myData =data;
        });
      });
	  
	  
	  app.controller('controller2',function($scope,$routeParams,countryService)
	  {
		countryService.find($routeParams.countryId,function(data) { 
		$scope.country=data;
		}); 
	  });
    
    /*countryApp.controller('CountryListCtrl', function ($scope, countries){
        countries.list(function(countries) {
          $scope.countries = countries;
        });
      });

      countryApp.controller('CountryDetailCtrl', function ($scope, $routeParams, countries){
        countries.find($routeParams.countryId, function(country) {
          $scope.country = country;
        });
      });*/