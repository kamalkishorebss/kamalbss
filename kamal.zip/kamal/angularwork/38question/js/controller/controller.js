 app.controller('controller1', function ($scope, $http){
        $http.get('countries.json').then(function(response) {
          $scope.myData =response.data;
        });
      });
      app.controller('controller2', function ($scope, $routeParams, $http){
        $scope.name = $routeParams.countryName;
        $http.get('country.json').then(function(arg) {
          var country = arg.filter(function(entry){
            return entry.name === $scope.name;
          })[0];
          console.log(country);
        });
      });