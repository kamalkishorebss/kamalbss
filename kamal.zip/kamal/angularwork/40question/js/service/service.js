app.factory("countryService",function($http){
    return {
      list: function(response){
      $http.get('countries.json').success(response);
      }
};
});