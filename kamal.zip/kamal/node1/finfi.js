var fs =require("fs");
console.log("going to get file");
 fs.stat('/Users/kamal.kishore/Desktop/kamal/node1/input.txt', function(err, stats){
 if(err)
 {
 return console.error(err);
 }
 console.log(stats);
  console.log("file info successfully");
  //check file type
  console.log("Is File?" + stats.isFile());
  console.log("isDirectory?" + stats.isDirectory());
 });
