app.controller("person1",function($scope,$timeout,$location){
	$scope.myHeader = "kamal";
  $timeout(function () {
      $scope.myHeader = "kamal kishore?";
  }, 2000);
  $scope.result=function()
{ alert("heloo");
	$location.path('/login');
}
});
 
app.controller("person2",function($scope,$location,loginservice){
$scope.user = function(){
	loginservice.check($scope.psw);
};

//console.log($scope.user);
});
app.controller("person3",function($scope){
$scope.msg = "Hello Angularjs";

});



