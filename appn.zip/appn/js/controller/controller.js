app.controller("person1",function($scope,$timeout,$location){
	$scope.myHeader = "Welcome in Angular App";
  $timeout(function () {
      $scope.myHeader = "Click the Links";
  }, 2000);
  
  $scope.result=function()
{ alert("heloo");
	$location.path('/login');
}
});
 
app.controller("person2",function($scope,$location,loginservice){
$scope.user = function(){
	loginservice.check($scope.psw);
};
$scope.sing=function()
{
	$location.path('/singup');
}
$scope.log=function()
{
	$location.path('/login');
}
//console.log($scope.user);
});
app.controller("person3",function($scope){
$scope.msg = "Hello Angularjs";

});



