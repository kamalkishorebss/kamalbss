var mongoose=require("mongoose");
var schema=mongoose.Schema;

var userSchema=new schema({
	local      : {
	name       :    String,
	username   :{ 
	             type: String, unique:true ,
	           },
	email      :{ 
	                type:String,unique:true
	            },
	password   : String,
	file:String
},
	google    : {
	name       :  String,
	username   :{ 
	               type: String, unique:true ,
	          },
	email      :{   
		          type:String,unique:true
		      },
	password   :String,
	file:String
}
})
var user=mongoose.model('user',userSchema);
module.exports=user;
