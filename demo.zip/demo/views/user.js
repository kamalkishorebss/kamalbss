var express = require('express');
var router = express.Router();
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var usercontrool=require("../model/userschema");
var multer=require('multer');
var mime=require('mime-types');
var path    = require("path");
var storage=multer.diskStorage({
	destination:function(req,file,cb){
		cb(null,'./public/uploads')
	},
	filename:function(req,file,cb){
		console.log('file',file);
		cb(null,Date.now() + '.' +mime.extension(file.mimetype));
	}
})
var upload = multer({ storage: storage });

// /* GET home page. */
 function ensureAuthenticated(req,res,next){     
if (req.isAuthenticated()) {
        next();   
        }
     
}

router.get('/logedin' ,function(req, res, next) {
 res.send(req.isAuthenticated() ? req.user : false);

 });
router.get('/profile' ,ensureAuthenticated,function(req, res, next) {
	// console.log(req);
    res.send(req.user);

 });

//**********************************************
router.post('/signup',upload.single('file') ,function(req, res, next) {
  var user= new usercontrool();
  user.local.name=req.body.name;
  user.local.username=req.body.username;
  user.local.email=req.body.email;
  user.local.password=req.body.password;
  user.local.file=req.file.filename;
   //console.log(user.file);
usercontrool.findOne({'local.email':req.body.email},function(err,person){
	if(err){
		res.send(err)
	}else{
		if(!person){
		user.save(function(err,person){
if(err){
	res.send(err)
}else{
	console.log(person);
	res.send(person);
}
});
}else{
	res.send(err)
}
}
		})
	
});
//*************************************

//**************************///
passport.use(new LocalStrategy(function(username, password, done) {
    usercontrool.findOne({'local.username': username }, function(err, user) {
      if (err) { return done(err); }
      if (!user) {
        return done(null, false, { message: 'Incorrect username.' });
      }
      if (user.local.password != password) {
        return done(null, false, { message: 'Incorrect password.' });
      }
      return done(null, user);
    });
  }));

//passport serialize user for their session
passport.serializeUser(function(user, done) {
  done(null, user.id);
});
//passport deserialize user 
passport.deserializeUser(function(id, done) {
  usercontrool.findById(id, function(err, user) {
    done(err, user);
  });
});
//********************************************
router.post('/login', passport.authenticate('local'), function(req, res){
	var user=req.body;
	console.log(user);
    res.send(req.user);

});
//**********logout user*************************
router.get('/logout', function(req, res){
	req.logout();
	res.send(req.user)
	console.log("user is logout")
	// res.redirect('/login');
});
router.get('/list',ensureAuthenticated,function(req, res, next) {
usercontrool.find({},function(err,data){
	if(err){
		res.send(err)
	}else{
		res.send(data)
	}
})

});
router.get('/single/:id',function(req, res, next) {
  
usercontrool.findById(req.params.id,function(err,data){
	if(err){
		res.send(err)
	}else{
		res.send(data)
	}
})

});

router.get('/edit/:id',function(req, res, next) {
  
usercontrool.findById(req.params.id,function(err,data){
	if(err){
		res.send(err)
	}else{
		res.send(data)
	}
})

});
router.put('/edit/:id', function(req, res, next) {
  
usercontrool.findById(req.params.id,function(err,data){
	data.name=req.body.name;
	console.log(data.name);
	data.save(function(err,data){
	if(err){
		res.send(err)
	}else{
		res.send(data)
	}	
	})
	
})

});
router.delete('/delete/:id', function(req, res, next) {
  
usercontrool.findById(req.params.id,function(err,data){
	data.remove(function(err,data){
			if(err){
		res.send(err)
	}else{
		res.send(data)
	}
	})

})

});
module.exports = router;
