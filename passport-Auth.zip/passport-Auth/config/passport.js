//var passport=require("passport");
var LocalStrategy   = require('passport-local').Strategy;
var User= require('../model/usermodel');
module.export=function(passport){

passport.serializeUser(function(user,done){
	done(null,user);
});
passport.deserializeUser(function(id,done){
	User.findBYId(id,function(err,user){
		done(err,user);
	});
	
});
passport.use('local-signup',new LocalStrategy({
userField:'email',
passwordField:'password',
passReqToCallback:true
},
function(req,email,password,done){
	process.nextClick(function(){
		User.findOne({email:email},function(err,user){
			if(err){
				return done(err);
			}
			if(user){
				return done(null,false)
			}else{
				var newuser= new User();
				newuser.email=email;
				newuser.password=password;
				newuser.save(function(err,user){
					if(err){
						    throw err;
					}else{
						return done(null, newUser);
					}
				});
			}
		})
	})
}))
}