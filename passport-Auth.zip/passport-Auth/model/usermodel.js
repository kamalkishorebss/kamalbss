var mongoose = require('mongoose');
var bcrypt   = require('bcrypt-nodejs');

var schema=mongoose.Schema;

var userSchema=new schema({
	username:String,
	email:{type:String,unique:true},
	password:String
})

var User=mongoose.model("user",userSchema)
module.exports=User;

module.exports.createUser = function(newUser, callback){
	bcrypt.genSalt(10, function(err, salt) {
	    bcrypt.hash(newUser.password, salt, function(err, hash) {
	        newUser.password = hash;
	        newUser.save(callback);
	    });
	});
}
module.exports.getUserByUsername = function(username, callback){
	var query = {username: username};
	User.findOne(query, callback);
}
module.exports.getUserById = function(id, callback){
	User.findById(id, callback);
}



// module.exports.login=function(req,res){
// var email=req.body.email;
// var password=req.body.password;
// //console.log(email);
// 			User.findOne({email:email},function(err,person){
// 				if(err){
// 					console.log('err',err);
// 					}
// 					else{
// 						if(person){
// 							if(person.password==password){
// 						        console.log(person)
// 								//res.send(person);
// 								res.redirect('/')

// 							}
// 							else{
// 								//res.send({error:'incorrect password'});
// 								res.redirect('/login')
// 							}
// 						}else{
// 							//res.send({error:'User name or password is worng'})
// 								res.redirect('/login')

// 						}
// 					}
// 				})
//      }