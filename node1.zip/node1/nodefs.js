var fs = require("fs");

fs.readFile('f.html', function (request, response) {
   response.writeHead(200, {'Content-Type': 'text/html'});
   response.end('Hello World\n');
});

console.log("Program Ended");