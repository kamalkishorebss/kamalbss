/*var main = new Buffer('ZABC');
var other = new Buffer('ABC');
var result = main.compare(other);
console.log(result);
*/
/*var buffer1 = new Buffer('ABC');
//copy a buffer
var buffer2 = new Buffer(5);
buffer1.copy(buffer2);
console.log("buffer2 content: " + buffer2.toString());*/
var buffer1 = new Buffer(" i m Indain");

var buffer2 = buffer1.slice(0,5);

console.log("buffer2 content: " + buffer2);
 var c = buffer2.length;
console.log("buffer2 lenght: " + c);