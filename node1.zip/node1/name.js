
console.log("kamal");
