var fs = require("fs");
var zlib = require("zlib");
fs.createReadStream('/Users/kamal.kishore/Desktop/kamal/node1/input.txt').
pipe(zlib.createGzip()).
pipe(fs.createWriteStream('/Users/kamal.kishore/Desktop/kamal/node1/input.txt.zp'));

console.log("Program End");