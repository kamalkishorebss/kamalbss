var app=angular.module("myApp",['ngRoute','ngStorage']);
app.config(["$routeProvider","$locationProvider",function($routeProvider,$locationProvider){
	$routeProvider.
	when("/signup",{
	controller:"main",
	templateUrl:"/javascripts/view/signup.html"
	}).
	when("/login",{
	controller:"main",
	templateUrl:"/javascripts/view/login.html"
   }).
	when("/edit",{
	controller:"listController",
	templateUrl:"/javascripts/view/edit.html",
		resolve: {
		logedin:checkLoggedin
	}
    }).
  when("/profile",{
	controller:"profileController",
	templateUrl:"/javascripts/view/profile.html",
	resolve: {
		logedin:checkLoggedin
	}
  }).
	when("/list",{
	controller:"listController",
	templateUrl:"/javascripts/view/list.html",
	resolve: {
		logedin:checkLoggedin
	}
   }).
    when("/singleView",{
	controller:"listController",
	templateUrl:"/javascripts/view/single.html"
  }).
    otherwise({
	redirectTo:'/'
	});
 $locationProvider.html5Mode({
                 enabled: true,
                requireBase: false
              });
}]);
var checkLoggedin = function($q, $timeout, $http, $location, $rootScope){
      // Initialize a new promise
      var deferred = $q.defer();
      $http.get('/users/loggedin').success(function(user){
        // Authenticated
        if(user !== '0'){
          //$timeout(deferred.resolve, 0);
        console.log("you are log in " + user);
          deferred.resolve();
             }
        // Not Authenticated
        else {
          $rootScope.message = 'You need to log in.';
          console.log("you are not log in " + user);
          deferred.reject();
         // $timeout(function(){deferred.reject();}, 0);
          $location.url('/login');
        }
      });
      return deferred.promise;
    };