app.controller('loginController',['$scope','$location','$http',function($scope,$location,$http){


$scope.error = '';
$scope.createAccountPage = function(){
    $location.path('/signup');
  }
$scope.userlogin=function(){
		$http({
		method:"post",
		url:'/users/login',
		data:{username:$scope.username,password:$scope.password,type: 'register'},
}).success(function(response){
	$scope.userData = response;


           console.log("success!!");
          $location.path("/profile")
        }).error(function(response){
           console.log("error!!");
            $location.path("/login")
        });

}
//signup function
$scope.uploadFile = function(){
        $http({
    method:"post",
    url:'/users/signup',
    data:{username:$scope.registrationForm.user.email,password:$scope.registrationForm.user.password,type: 'register'},
}).success(function(response){
           console.log("success!!");
          $location.path("/profile")
        }).error(function(response){
           console.log("error!!");
           // $location.path("/login")
        });

}


 /*       var file = $scope.registrationForm.user.myFile;
        var uploadUrl = "users/signup";
        var fd = new FormData();
        fd.append('username',$scope.registrationForm.user.username);
        fd.append('email',$scope.registrationForm.user.email);
        fd.append('password',$scope.registrationForm.user.password);
        fd.append('file', file);
        fd.append('gender',$scope.registrationForm.user.gender);
        //JSON.stringify({username:$scope.registration.user.username,email:$scope.registration.user.email,password:$scope.registration.user.password, file:file})
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
          console.log("success!!");
          $location.path("/login")
        })
        .error(function(){
          console.log("error!!");
        });
    };
*/
}]);