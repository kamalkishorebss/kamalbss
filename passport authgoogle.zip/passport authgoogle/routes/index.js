var express = require('express');
var router = express.Router();
var Usermodel = require('../module/usermodel');
var Googlemodel = require('../module/googlemodel');
var Facebookmodel = require('../module/facebookmodel');
var passport = require('passport');
var LocalStrategy=require("passport-local").Strategy;
var GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;
var FacebookStrategy = require('passport-facebook').Strategy;
//var flash    = require('connect-flash');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

function isAuthincation(req,res,next){
	if(req.isAuthenticated()){
		return next();
	}
	else {
		res.redirect('/login');
}
}
router.get('/login', function(req, res, next) {
  res.render('login', { title: 'login' });
});

router.get('/signup', function(req, res, next) {
  res.render('sign', { title: 'sign' });
});

router.get('/profile', isAuthincation,function(req, res, next) {
  res.render('profile', { data:req.user });
});

router.get('/profiles', isAuthincation, function(req, res) {
        res.render('profiles', {
            user : req.user // get the user out of session and pass to template
        });
    });
	


//authincation with google*********************************************
router.get('/auth/google', passport.authenticate('google', { scope : ['profile', 'email'] }));

    // the callback after google has authenticated the user
    router.get('/auth/google/callback',
            passport.authenticate('google', {
                    successRedirect : '/profile',
                    failureRedirect : '/login',
					failureFlash : true
            }));

	

    passport.deserializeUser(function(id, done) {
        Googlemodel.findById(id, function(err, user) {
            done(err, user);
        });
    });

passport.use(new GoogleStrategy({

        clientID        : '1095783459776-obvi0g09bbh2o3tie6aumnfutjque7ml.apps.googleusercontent.com',
        clientSecret    : '8A4Lc2j66hV4TaKwYvdLBQDA',
        callbackURL     : '/auth/google/callback'

    },
    function(token, refreshToken, profile, done) {

        // make the code asynchronous
        // User.findOne won't fire until we have all our data back from Google
        process.nextTick(function() {

            // try to find the user based on their google id
            Googlemodel.findOne({ 'google.id' : profile.id }, function(err, user) {
                if (err)
                    return done(err);

                if (user) {

                    // if a user is found, log them in
                    return done(null, user);
                } else {
                    // if the user isnt in our database, create a new user
                    var newUser = new Googlemodel();

                    // set all of the relevant information
                    newUser.google.id    = profile.id;
                    newUser.google.token = token;
                    newUser.google.name  = profile.displayName;
                    newUser.google.email = profile.emails[0].value; // pull the first email

                    // save the user
                    newUser.save(function(err) {
                        if (err)
                            throw err;
                        return done(null, newUser);
                    });
                }
            });
        });

    }));
	
//authincation with facebook*******************************************************************************
router.get('/auth/facebook', passport.authenticate('facebook', { scope : 'email' }));

    // handle the callback after facebook has authenticated the user
    router.get('/auth/facebook/callback',
        passport.authenticate('facebook', {
            successRedirect : '/profiles',
            failureRedirect : '/'
        }));
		
		  passport.deserializeUser(function(id, done) {
         Facebookmodel.findById(id, function(err, user) {
            done(err, user);
        });
    });
passport.use(new FacebookStrategy({

        // pull in our app id and secret from our auth.js file
        clientID        : '1289500094397561',
        clientSecret    : '027fb6ed4454d448bb129468df612547',
        callbackURL     : '/auth/facebook/callback'

    },

    // facebook will send back the token and profile
    function(token, refreshToken, profile, done) {

        // asynchronous
        process.nextTick(function() {

            // find the user in the database based on their facebook id
            Facebookmodel.findOne({ 'facebook.id' : profile.id }, function(err, user) {

                // if there is an error, stop everything and return that
                // ie an error connecting to the database
                if (err)
                    return done(err);

                // if the user is found, then log them in
                if (user) {
                    return done(null, user); // user found, return that user
                } else {
                    // if there is no user found with that facebook id, create them
                    var newUser = new Facebookmodel();

                    // set all of the facebook information in our user model
                    newUser.facebook.id    = profile.id; // set the users facebook id                   
                    newUser.facebook.token = token; // we will save the token that facebook provides to the user                    
                    newUser.facebook.name  = profile.name.givenName + ' ' + profile.name.familyName; // look at the passport user profile to see how names are returned
                    newUser.facebook.email = profile.emails[0].value; // facebook can return multiple emails so we'll take the first

                    // save our user to the database
                    newUser.save(function(err) {
                        if (err)
                            throw err;

                        // if successful, return the new user
                        return done(null, newUser);
                    });
                }

            });
        });

    }));



	
router.post('/signup',function(req,res,next){
	
	var user = new Usermodel();
	user.username = req.body.username;
	user.email = req.body.email;
	user.password = req.body.password;
Usermodel.findOne({email:req.body.email},function(err,person){
	if(err){
		res.send(err);
	}
	else {
		if(!person)
		{
			user.save(function(err,data){
			if(err)
			{
				console.log(err);
			}
			else
			{
				//console.log(data);
				res.send(data);
				res.redirect('/login');
			}
			})
		}else{
			console.log("user already registerd");
		}
	}
});
	});
	
router.post('/login', passport.authenticate('local',{successRedirect : '/profile',failureRedirect : '/login'}),
		function(req, res, next) {
	    res.redirect('/'); 
		
});
	
	/*var username = req.body.username;
	var password = req.body.password;
	
   Usermodel.findOne({username:username},function(err,person){
	if(err)
	{ 
        //console.log(err);
		res.send(err);
	}
	else
	{
	      if(person)
		  {
			  if(person.password == password)
			  {
				  //res.send({status:true,data:person});
                  res.redirect('/profile');				
				//console.log(data);
			  }
			  else
			  {
				console.log("Invalid password");
			  res.send({error:'Invalid password'});
			  }
			  
		  }
		  
		  else
		  {
			console.log("Invalid Email");
			  res.send({error:'Email is invalid'});
		  }
	}
});*/

	//**serializer&deserializer
	 passport.serializeUser(function(user, done) {
        done(null, user.id);
    });

    passport.deserializeUser(function(id, done) {
        Usermodel.findById(id, function(err, user) {
            done(err, user);
        });
    });

//**checkeing locally**************
passport.use(new LocalStrategy(function(username,password,done){
	Usermodel.findOne({username:username},function(err,user){
		if(err){
		return done(err);
		}
		if (!user) 
		    {
			return done(null, false);
			}
		if(user.password != password)
			{
				return done(null, false);
			}
			return done(null, user);
	});	
}));






router.get('/logout', function(req, res) {
		req.logout();
		res.redirect('/');
	});
module.exports = router;
