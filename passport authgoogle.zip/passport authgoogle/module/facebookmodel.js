var mongoose = require('mongoose');
//var bcrypt   = require('bcrypt-nodejs');


var facebookSchema = mongoose.Schema({
        facebook         : {
        id           : String,
        token        : String,
        email        : String,
        name         : String
    }
    });
	
var Facebook = mongoose.model('facebook',facebookSchema);
	
module.exports = Facebook;