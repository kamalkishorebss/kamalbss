var mongoose = require('mongoose');
//var bcrypt   = require('bcrypt-nodejs');


var googleSchema = mongoose.Schema({
	    google           : {
        id           : String,
        token        : String,
        email        : String,
        name         : String
    }
    });
	
var Google = mongoose.model('google',googleSchema);
	
module.exports = Google;