var app= angular.module("myApp", []);
//---------------main-controller----------------------
app.controller("mycontroller",function($scope,$interval){
$scope.names=[{name:"Ranbir"},{name:"Ritik"},{name:"Sahrukh"},{name:"Salman"}];
$scope.messageMode=false;
$scope.addName=function(){
           $scope.names.push({name: $scope.nameInput});
          $scope.nameInput='';
         }
$scope.meText = [{text: 'hello' },{text: 'hello' }];
$scope.textarray = ["Hey there!", "What is your favorite color?","Do you like animals?","HEY!","where r u","kuuteee","heheheh","byee","go to hell","):","are u maid"];

$scope.arrLen=$scope.textarray.length;
console.log($scope.arrLen);
$scope.addMessage=function(){
$scope.count=0;
$scope.timer=$interval(function(){
 $scope.meText.push({text:$scope.textarray[Math.floor(Math.random() * $scope.arrLen)+1]});
 $scope.count++;
 if($scope.count %2 !=0)
       {
       $interval.cancel($scope.timer);
        $scope.timer=undefined;
          }
},1000);
$scope.meText.push({text:$scope.textInput});
   $scope.textInput='';
}
$scope.myimage={img:"delete.png",img2:"https://cloud.githubusercontent.com/assets/16836807/13006072/5772feae-d1ac-11e5-88a1-afdce83b4bb9.jpg",img3:"https://cloud.githubusercontent.com/assets/16836807/13006056/3d0ad776-d1ac-11e5-9080-2e6ae435d9b4.jpg",img4:"https://cloud.githubusercontent.com/assets/16836807/13006208/4149df02-d1ad-11e5-96de-91d50fd85a41.jpg"}	

});